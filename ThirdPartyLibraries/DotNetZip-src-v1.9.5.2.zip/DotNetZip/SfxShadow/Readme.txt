Tue, 27 Oct 2009  06:02

This is a "shadow" project. 
All the source code goes into the DotNetZip dll as embedded resource
(encased in a zip file).  

But I need to be able to design the dialogs.  So this project lets me do
that.  

