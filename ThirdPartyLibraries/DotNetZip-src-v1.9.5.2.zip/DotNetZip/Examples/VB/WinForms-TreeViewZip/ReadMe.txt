Tue, 27 Oct 2009  00:46

This application shows how to open and read a zip file, and display the
contents in a Windows Forms TreeView. 

The app is written in VB.
